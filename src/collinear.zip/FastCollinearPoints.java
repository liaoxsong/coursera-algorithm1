

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.Merge;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

public class FastCollinearPoints {

	private List<LineSegment> mLineSegments;

	public FastCollinearPoints(Point[] points) {
		
		if (points == null) throw new NullPointerException("points array is null");
		if (containsDuplicate(points)) throw new IllegalArgumentException("repeated point detected");
		   
		
		mLineSegments = new ArrayList<>();
		// now starts finding
		findCollinearPoints(points);
	}

	private void findCollinearPoints(Point[] points) {
		int N = points.length;
//		System.out.println("findCollinearPoints");
			
		for (int i = 0; i < N - 3; i++) {
			Arrays.sort(points, i + 1, points.length, points[i].slopeOrder());
			
			HashMap<Double, List<Point>> map = new HashMap<>();//I need a way out..
			double currentSlope = points[i].slopeTo(points[i + 1]);
			map.put(currentSlope, new ArrayList<Point>(Arrays.asList(points[i], points[i + 1])));
			;

			//System.out.println("at 1 :" + points[i + 1] + " 's slo pe " + currentSlope);

			for (int k = i + 2; k < N; k++) {
				double slope = points[i].slopeTo(points[k]);
				//System.out.println("at " + k + " :" + points[k] + " 's slope " + slope);

				if (slope == currentSlope) {
					List<Point> pts = map.get(slope);
					if (!pts.contains(points[k])) {
						pts.add(points[k]);
						map.put(slope, pts);
					}
				} else {

					currentSlope = slope;
					map.put(currentSlope, new ArrayList<Point>(Arrays.asList(points[i], points[k])));
				}
			}
			for (Double d : map.keySet()) {
				List<Point> pts = map.get(d);
				if (pts.size() >= 3) {
					Collections.sort(pts);
					mLineSegments.add(new LineSegment(pts.get(0), pts.get(pts.size() - 1)));
				}
			}
		}
	}

	// the number of line segments
	public int numberOfSegments() {
		return mLineSegments.size();
	}

	// the line segments
	public LineSegment[] segments() {
		return mLineSegments.toArray(new LineSegment[mLineSegments.size()]);
	}

	public static void main(String[] args) {
		// read the n points from a file
		
		String localFile = "/Users/song/Documents/EclipseWorkspace/HelloEclipse/src/collinear/input8.txt";
		//File file = new File(args[0]);
		File file = new File(args[0]);
		In in = new In(file);
		int n = in.readInt();

		Point[] points = new Point[n];
		for (int i = 0; i < n; i++) {
			int x = in.readInt();
			int y = in.readInt();
			points[i] = new Point(x, y);
		}
		// points[0] = new Point(0, 1);
		// points[1] = new Point(2, 2);
		// points[2] = new Point(4, 4);
		// points[3] = new Point(4, 3);
		// points[4] = new Point(5, 5);
		// points[5] = new Point(10, 10);

		// draw the points
		StdDraw.enableDoubleBuffering();
		StdDraw.setXscale(0, 32768);
		StdDraw.setYscale(0, 32768);
		StdDraw.setPenRadius(0.01);
		for (Point p : points) {

			p.draw();
		}
		StdDraw.show();

		// print and draw the line segments
		FastCollinearPoints collinear = new FastCollinearPoints(points);
		StdOut.println("segments:" + collinear.numberOfSegments());
		for (LineSegment segment : collinear.segments()) {
			StdOut.println(segment);
			segment.draw();
		}
		StdDraw.show();
	}
	
	private boolean containsDuplicate(Point[] points) {
		Point [] copy = points.clone();
		Arrays.sort(copy);
		for(int i=0;i<copy.length-1;i++) {
			if (points[i]==null) throw new NullPointerException("a point is null");
			if (points[i].compareTo(points[i+1]) == 0) {
				return true;
			}
		}
		return false;
	}

}
